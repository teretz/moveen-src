
Moveen is a library for automatic mech animation - it adds common cinematic grade animations to any robot model.

1. Don't hesitate! Send me your questions, claims, suggestions, bug reports. It is important for me to know what to improve, what the problems are, and where to move.

2. Make a review in the Asset Store. It will motivate me to put more work into the lib... which you already own!

3. Share with me your videos or posts about your models + Moveen. It is possible that I'll share or retweet them.

4. The question of the version. If you are in need of implement a mix of Moveen and animations, or ragdoll and animations, or all three of them - let me know about your use-case. I am currently trying to figure out best API and UI for those features.

Project site: https://kravchik.github.io/moveen/
Discord chat: https://discord.gg/uTD8Gj4
Tutorials: https://www.youtube.com/watch?v=P72QUrl86xI&index=2&list=PLqZriYKM4MpAqF17lRU8c-QVK5QzDQHdW
My e-main: kravchiky@gmail.com







