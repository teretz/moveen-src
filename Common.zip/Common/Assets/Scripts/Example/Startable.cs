﻿namespace moveen.example {
    public interface Startable {
        void start();
    }
}