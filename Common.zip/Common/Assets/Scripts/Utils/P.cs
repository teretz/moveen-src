
namespace moveen.utils {
    public class P<T> {
        public T v;

        public P() {
        }

        public P(T t) {
            v = t;
        }
    }
}