﻿using UnityEngine;

namespace moveen.utils {
    public class BindWarningAttribute : PropertyAttribute {
    }
}