namespace moveen.utils {
    public struct Tuple<A, B> {
        public A a;
        public B b;
    }
}