﻿using UnityEngine;

namespace moveen.utils {
    public class InstrumentalInfoAttribute : PropertyAttribute
    {
    }
}