namespace moveen.utils {
    public interface Consumer<A> {
        void accept(A a);
    }
}