namespace moveen.utils {
    public interface Tickable {
        void tick(float dt);
    }
}