namespace moveen.utils {
    public interface BiConsumer<A, B> {
        void accept(A a, B b);
    }
}