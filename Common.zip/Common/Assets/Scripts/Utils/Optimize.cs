﻿using System;

namespace moveen.utils {
    [AttributeUsage(AttributeTargets.All)]
    public class Optimize : Attribute 
    {
    }
}