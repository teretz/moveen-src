﻿using UnityEngine;

namespace moveen.utils {
    public class BindOrLocalWarningAttribute : PropertyAttribute {
    }
}