﻿using UnityEngine;

namespace moveen.utils {
    public class ReadOnlyAttribute : PropertyAttribute
    {
    }
 
}